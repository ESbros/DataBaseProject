﻿Public Class AgregarReunion
    Private Sub AgregarReunion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True
        RadioButton2.Select()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "SELECT id_reunion, tema, ubicacion, fecha :: varchar FROM reunion WHERE "
        sSQL = sSQL + "tema Like '" + "%'"
        'MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Ubicacion
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Nivel
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)
        End While
    End Sub
    Private Sub AgregarReunion_Click(sender As Object, e As EventArgs) Handles MyBase.Click

        DataGridView1.Rows.Clear()
        Try

            Dim cmd As New Odbc.OdbcCommand
            Dim dr As Odbc.OdbcDataReader
            Dim sSQL As String
            sSQL = "SELECT id_reunion, tema, ubicacion, fecha :: varchar FROM reunion WHERE "
            If RadioButton1.Checked Then
                sSQL = sSQL + "tema Like '" + TextBox1.Text + "%'"
            ElseIf RadioButton2.Checked Then
                sSQL = sSQL + "cast(fecha as text) Like '" + TextBox1.Text + "%'"
            ElseIf RadioButton3.Checked Then
                sSQL = sSQL + " ubicacion Like '" + TextBox1.Text + "%'"
            End If
            'MsgBox(sSQL)
            cmd.CommandText = sSQL
            cmd.Connection = Form1.gcn
            dr = cmd.ExecuteReader()

            While dr.Read()
                DataGridView1.Rows.Add()
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Ubicacion
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Nivel
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)
            End While
        Catch ex As Exception
            MsgBox(Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox3.Text = "" Then
            MsgBox("Llene todos los campos.", vbInformation)
        Else
            If vbYes = MsgBox("Agregar reunion el día " + DateTimePicker1.Value + "en " + cboubic.Text, vbYesNo) Then

                Dim sSQL As String
                Dim cmd As New Odbc.OdbcCommand
                sSQL = "Insert into reunion values( "
                sSQL = sSQL + "default" + ",'" + TextBox3.Text + "','" + cboubic.Text + "','" + DateTimePicker1.Value + "')"
                MsgBox(sSQL)

                Try
                    cmd.CommandText = sSQL
                    cmd.Connection = Form1.gcn
                    cmd.ExecuteNonQuery()

                Catch
                    MsgBox(Err.Description, MsgBoxStyle.Critical)
                    Exit Sub
                End Try
                MsgBox("Registro añadido")
            End If
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Clear()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "SELECT id_reunion, tema, ubicacion, fecha :: varchar FROM reunion WHERE "
        If RadioButton1.Checked Then
            sSQL = sSQL + "tema Like '" + TextBox1.Text + "%'"
        ElseIf RadioButton2.Checked Then
            sSQL = sSQL + "cast(fecha as text) Like '" + TextBox1.Text + "%'"
        ElseIf RadioButton3.Checked Then
            sSQL = sSQL + " ubicacion Like '" + TextBox1.Text + "%'"
        End If
        MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Ubicacion
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Nivel
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)
        End While
    End Sub
    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox2.Enabled = False
        TextBox2.Text = DataGridView1.CurrentRow.Cells(0).Value
        TextBox3.Text = DataGridView1.CurrentRow.Cells(1).Value
        cboubic.Text = DataGridView1.CurrentRow.Cells(2).Value
        DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(3).Value
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)
        Dim sSQL As String = "DELETE FROM reunion WHERE id_reunion = " + TextBox2.Text
        Dim cmd As New Odbc.OdbcCommand

        Try
            cmd.CommandText = sSQL
            cmd.Connection = Form1.gcn
            cmd.ExecuteNonQuery()
            DataGridView1.Rows().RemoveAt(DataGridView1.CurrentRow.Index)
        Catch
            MsgBox(Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
        TextBox1.Enabled = True

        Button4.Enabled = False
        Button2.Enabled = True
        TextBox1.Text = " "
        TextBox2.Text = " "
        TextBox3.Text = " "
        cboubic.Text = " "
        DateTimePicker1.Value = Now
        MsgBox("Registro eliminado")
    End Sub
    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If vbYes = MsgBox("Actualizar reunionel día " + DateTimePicker1.Value + "en " + cboubic.Text, vbYesNo) Then

            Dim sSQL1 As String
            Dim cmd As New Odbc.OdbcCommand
            sSQL1 = "update reunion set  tema = '" + TextBox3.Text + "', ubicacion = '" + cboubic.Text + "', fecha = '" + DateTimePicker1.Value + "' WHERE id_reunion = " + TextBox2.Text
            MsgBox(sSQL1)

            Try
                cmd.CommandText = sSQL1
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()

            Catch
                MsgBox(Err.Description, MsgBoxStyle.Critical)
                Exit Sub
            End Try
            MsgBox("Registro Actualizado")
        End If

    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub

    Private Sub cboubic_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboubic.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub
    Private Sub AgregarReunion_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = Not Char.IsControl(e.KeyChar)
        If RadioButton1.Checked Then
            If Char.IsLetter(e.KeyChar) Then
                e.Handled = False
            End If
        ElseIf RadioButton2.Checked Then
            If IsNumeric(e.KeyChar) Then
                e.Handled = False
            ElseIf Char.IsPunctuation(e.KeyChar) Then
                e.Handled = False
            End If
        ElseIf RadioButton3.Checked Then
            If Char.IsLetter(e.KeyChar) Then
                e.Handled = False
            ElseIf IsNumeric(e.KeyChar) Then
                e.Handled = False
            End If
        End If
    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged
        TextBox2.Enabled = False
    End Sub
End Class