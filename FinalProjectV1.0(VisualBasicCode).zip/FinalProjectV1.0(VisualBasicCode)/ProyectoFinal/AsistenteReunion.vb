﻿Public Class AsistenteReunion
    Private Sub AsistenteReunion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim query As String
            query = "select id_reunion, ubicacion, fecha,tema from reunion"
            cargar.CargaReunion(query, cboidr)
            query = "select nombre ||' '|| apellido, id_miembro as Miembro from miembro"
            cargar.CargaMiembro(query, cbonomb, cboci)
            cargar.AutocomS(query, cbonomb)
            cargar.AutocomS(query, cboci)

        Catch ex As Exception
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try

    End Sub

    Private Sub cboci_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboci.SelectedIndexChanged
        cbonomb.SelectedIndex = cboci.SelectedIndex
    End Sub
    Private Sub cbonomb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbonomb.SelectedIndexChanged
        cboci.SelectedIndex = cbonomb.SelectedIndex
    End Sub


    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        If vbYes = MsgBox("Agregar asistente: " + cbonomb.Text + "con CI: " + cboci.Text + "a la reunion" + cboidr.Text, vbYesNo) Then
            Dim sSQL As String
            sSQL = "insert into asistio_r values(" + cboci.Text + "," + cboidr.Text + ")"
            Try
                Dim cmd As New Odbc.OdbcCommand
                cmd.CommandText = sSQL
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()
                MsgBox("Agregado")
            Catch
                MsgBox("Al agregar un asistente" + Err.Description, MsgBoxStyle.Critical)
                Exit Sub
            End Try
            MsgBox("Agregado", vbInformation)
        End If


    End Sub

    Private Sub cboidr_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboidr.SelectedIndexChanged
        Try
            Dim dr As Odbc.OdbcDataReader
            Dim cmd As New Odbc.OdbcCommand
            cmd.Connection = Form1.gcn
            cmd.CommandText = "select ubicacion, tema, fecha from reunion where id_reunion = " + cboidr.Text
            dr = cmd.ExecuteReader()
            While dr.Read()
                txtubi.Text = dr(0)
                txttema.Text = dr(1)
                txtfecha.Text = dr(2)
            End While
        Catch
            MsgBox("Al cargar datos de la reunion" + Err.Description, MsgBoxStyle.Critical)
        End Try

    End Sub

    Private Sub cbonomb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbonomb.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub

    Private Sub cboci_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cboci.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub


End Class