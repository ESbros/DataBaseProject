﻿Public Class Form1
    Public gcn As New Odbc.OdbcConnection
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strCon As String
        strCon = "Driver={PostgreSQL ANSI};"
        strCon = strCon + "database=TrekkingFP;"
        strCon = strCon + "server=localhost;"
        strCon = strCon + "port=5432;"
        strCon = strCon + "uid=postgres;"
        strCon = strCon + "pwd=1234;" '

        gcn.ConnectionString = strCon
        gcn.Open()
        Try
            CargaDirectiva1()
            CargaDirectiva2()
            CargaDirectiva3()
        Catch ex As Exception
            MsgBox("Error al cargar la directiva.")
        End Try

    End Sub

    Private Sub AgregarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem.Click
        Dim ventana As New AgregarReunion
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AsistenciaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AsistenciaToolStripMenuItem.Click
        Dim ventana As New AsistenteReunion
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AgregarToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem1.Click
        Dim ventana As New Viaje
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AsistenciaToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles AsistenciaToolStripMenuItem1.Click
        Dim ventana As New AsistenciaViaje
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AgregarToolStripMenuItem3_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem3.Click
        Dim ventana As New Transporte
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AgregarToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem2.Click
        Dim ventana As New Destinos
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub ActualizarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ActualizarToolStripMenuItem.Click
        Dim ventana As New Directiva
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub ConsultarToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultarToolStripMenuItem.Click
        Dim ventana As New InfoViaje
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Public Sub CargaDirectiva1()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = gcn
        cmd.CommandText = "select nombre ||' '|| apellido, descripcion from directiva natural join miembro where id_cargo = 1"

        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox1.Text = dr(0)
        End While
    End Sub

    Public Sub CargaDirectiva2()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = gcn
        cmd.CommandText = "select nombre ||' '|| apellido, descripcion from directiva natural join miembro where id_cargo = 2"
        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox2.Text = dr(0)
        End While
    End Sub

    Public Sub CargaDirectiva3()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = gcn
        cmd.CommandText = "select nombre ||' '|| apellido, descripcion from directiva natural join miembro where id_cargo = 3"

        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox3.Text = dr(0)
        End While
    End Sub

    Private Sub AgregarToolStripMenuItem4_Click(sender As Object, e As EventArgs) Handles AgregarToolStripMenuItem4.Click
        Dim ventana As New AñadirMiembro
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub ConsultarToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ConsultarToolStripMenuItem1.Click
        Dim ventana As New inforeunion
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub ConsultaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConsultaToolStripMenuItem.Click
        Dim ventana As New Consultar_Miembro
        ventana.MdiParent = Me
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        ventana.Show()
        PictureBox1.Visible = False
        GroupBox1.Visible = False
    End Sub

    Private Sub AgregarReunion_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        CargaDirectiva1()
        CargaDirectiva2()
        CargaDirectiva3()
        GroupBox1.Visible = True
        PictureBox1.Visible = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            System.Diagnostics.Process.Start("https://www.facebook.com/trekkingyachay/")
        Catch

        End Try
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show(
        "¿Desea salir del programa?", "Cerrar el programa",
        MessageBoxButtons.YesNo) = DialogResult.No Then

            ' Cancelamos el cierre del formulario
            e.Cancel = True
        End If
    End Sub


End Class
