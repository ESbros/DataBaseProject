﻿Public Class Directiva
    Private Sub Directiva_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DateTimePicker2.Format = DateTimePickerFormat.Custom
        DateTimePicker2.CustomFormat = "yyyy-MM-dd"

        DataGridView1.Rows.Clear()
        Try
            Dim cmd1 As New Odbc.OdbcCommand
            Dim dr1 As Odbc.OdbcDataReader
            Dim sSQL1 As String
            sSQL1 = "select id_cargo, descripcion, id_miembro, fecha_inicio from directiva order by id_cargo"

            cmd1.CommandText = sSQL1
            cmd1.Connection = Form1.gcn
            dr1 = cmd1.ExecuteReader()

            While dr1.Read()
                DataGridView1.Rows.Add()
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr1(0)   'ID
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr1(1)   'Ubicacion
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr1(2)   'Nivel
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr1(3)
            End While
            sSQL1 = "select nombre ||' '|| apellido, id_miembro as Miembro from miembro"
            cargar.CargaMiembro(sSQL1, cbonomb, ComboBox1)
            cargar.AutocomS(sSQL1, cbonomb)
            cargar.AutocomS(sSQL1, ComboBox1)
        Catch ex As Exception

        End Try


        'CargaComboMiembro()
        CargaComboCargos()
    End Sub

    Public Sub CargaComboCargos()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select descripcion from cargos"
        dr = cmd.ExecuteReader()
        While dr.Read()
            ComboBox3.Items.Add(dr(0))
        End While
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        cbonomb.SelectedIndex = ComboBox1.SelectedIndex
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If vbYes = MsgBox("Desea actualizar el cargo de " + ComboBox3.Text + " registro", vbYesNo) Then
            Dim sSQL As String
            Dim cmd As New Odbc.OdbcCommand
            sSQL = "delete from directiva where descripcion = '" + ComboBox3.Text + "';"
            sSQL = sSQL + "insert into directiva values(" + TextBox1.Text + ", '" + ComboBox3.Text + "', " + ComboBox1.Text + ", '" + DateTimePicker2.Text + "');"
            MsgBox(sSQL)
            Try
                cmd.CommandText = sSQL
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()
            Catch
                MsgBox("Agregue Datos.", MsgBoxStyle.Critical)
                Exit Sub
            End Try
            MsgBox("Registro añadido")

            DataGridView1.Rows.Clear()
            Dim cmd1 As New Odbc.OdbcCommand
            Dim dr1 As Odbc.OdbcDataReader
            Dim sSQL1 As String
            sSQL1 = "select id_cargo, descripcion, id_miembro, fecha_inicio :: varchar from directiva order by id_cargo"

            MsgBox(sSQL1)
            cmd1.CommandText = sSQL1
            cmd1.Connection = Form1.gcn
            dr1 = cmd1.ExecuteReader()

            While dr1.Read()
                DataGridView1.Rows.Add()
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr1(0)   'ID
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr1(1)   'Ubicacion
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr1(2)   'Nivel
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr1(3)
            End While
        End If
    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox3.SelectedIndexChanged
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select id_cargo from cargos where descripcion = " + "'" + ComboBox3.Text + "'"
        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox1.Text = dr(0)
        End While
    End Sub

    Private Sub ComboBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ComboBox1.KeyPress
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub



    Private Sub cbonomb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbonomb.SelectedIndexChanged
        ComboBox1.SelectedIndex = cbonomb.SelectedIndex
    End Sub

    Private Sub cbonomb_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cbonomb.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
        Form1.CargaDirectiva1()
        Form1.CargaDirectiva2()
        Form1.CargaDirectiva3()
    End Sub

End Class