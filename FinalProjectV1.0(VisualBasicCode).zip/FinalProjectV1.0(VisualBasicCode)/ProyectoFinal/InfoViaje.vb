﻿Public Class InfoViaje

    Private Sub InfoViaje_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CargaComboIDviaje()
    End Sub

    Public Sub CargaComboIDviaje()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select id_viaje, ubicacion, fecha from viaje natural join destino order by id_viaje desc"
        dr = cmd.ExecuteReader()
        While dr.Read()
            ComboBox1.Items.Add(dr(0))
        End While
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select ubicacion, fecha from viaje natural join destino where id_viaje = " + ComboBox1.Text
        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox1.Text = dr(0)
            TextBox2.Text = dr(1)
        End While
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        grdasviaje.Rows.Clear()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "select nombre || ' ' || apellido from miembro as Miembro where id_miembro in (
select id_miembro as id from asistio_d  where id_viaje =" + ComboBox1.Text + ")"
        MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            grdasviaje.Rows.Add()
            grdasviaje.Rows(grdasviaje.RowCount - 1).Cells(0).Value = dr(0)   'Nombre
        End While

        Dim cmd1 As New Odbc.OdbcCommand
        Dim dr1 As Odbc.OdbcDataReader
        Dim sSQL1 As String
        sSQL1 = "select count(*) from miembro as Miembro where id_miembro in (
select id_miembro as id from asistio_d  where id_viaje =" + ComboBox1.Text + ")"
        cmd1.CommandText = sSQL1
        cmd1.Connection = Form1.gcn
        dr1 = cmd1.ExecuteReader()
        While dr1.Read()
            TextBox3.Text = dr1(0)
        End While

        Dim cmd2 As New Odbc.OdbcCommand
        Dim dr2 As Odbc.OdbcDataReader
        Dim sSQL2 As String
        sSQL2 = "select sum(cuota) from asistio_d where id_viaje = " + ComboBox1.Text
        Try
            cmd2.CommandText = sSQL2
            cmd2.Connection = Form1.gcn
            dr2 = cmd2.ExecuteReader()
            While dr2.Read()
                TextBox4.Text = dr2(0)
            End While
        Catch
            MsgBox("No Se encontraron miembors registrados")
        End Try
    End Sub

    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
End Class