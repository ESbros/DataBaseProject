﻿Public Class AñadirMiembro
    Private Sub AñadirMiembro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True

        RadioButton1.Select()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "SELECT id_miembro, nombre, apellido, fecha_nac::varchar, fecha_ingreso::varchar, mail, telefono  "
        sSQL = sSQL + "FROM miembro "
        If RadioButton1.Checked Then
            sSQL = sSQL + "WHERE nombre Like '" + TextBox5.Text + "%'"
        ElseIf RadioButton3.Checked Then
            sSQL = sSQL + "WHERE cast(id_miembro as text) Like '" + TextBox5.Text + "%'"
        End If
        '  MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Nombre
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Apellido
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)   'FN
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(4).Value = dr(4)   'FI
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(5).Value = dr(5)   'Telefono
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(6).Value = dr(6)
        End While
    End Sub
    Private Sub AñadirMiembro_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        DataGridView1.Rows.Clear()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "SELECT id_miembro, nombre, apellido, fecha_nac::varchar, fecha_ingreso::varchar, mail, telefono  "
        sSQL = sSQL + "FROM miembro "
        sSQL = sSQL + "WHERE cast(id_miembro as text) Like '" + "%'"
        ' MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Nombre
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Apellido
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)   'FN
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(4).Value = dr(4)   'FI
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(5).Value = dr(5)   'Telefono
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(6).Value = dr(6)
        End While
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Clear()
        'Dim aux As String
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        Try



            sSQL = "SELECT id_miembro, nombre, apellido, fecha_nac::varchar, fecha_ingreso::varchar, mail, telefono  "
            sSQL = sSQL + "FROM miembro "
            If RadioButton1.Checked Then
                sSQL = sSQL + "WHERE nombre Like '" + TextBox5.Text + "%'"
            ElseIf RadioButton3.Checked Then
                sSQL = sSQL + "WHERE cast(id_miembro as text) Like '" + TextBox5.Text + "%'"
            End If
            MsgBox(sSQL)
            cmd.CommandText = sSQL
            cmd.Connection = Form1.gcn
            dr = cmd.ExecuteReader()

            While dr.Read()
                DataGridView1.Rows.Add()
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Nombre
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)   'Apellido
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)   'FN
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(4).Value = dr(4)   'FI
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(5).Value = dr(5)   'Telefono
                DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(6).Value = dr(6)
            End While

        Catch
            MsgBox("Coloque algo")
        End Try

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        TextBox1.Enabled = False

        Try
            TextBox1.Text = DataGridView1.CurrentRow.Cells(0).Value
            TextBox2.Text = DataGridView1.CurrentRow.Cells(1).Value
            TextBox3.Text = DataGridView1.CurrentRow.Cells(2).Value
            TextBox4.Text = DataGridView1.CurrentRow.Cells(6).Value
            TextBox6.Text = DataGridView1.CurrentRow.Cells(5).Value
            DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(3).Value
            DateTimePicker2.Value = DataGridView1.CurrentRow.Cells(4).Value
        Catch

        End Try

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If vbYes = MsgBox("Eliminar registro:  " + vbCr + " CI: " + TextBox1.Text + vbCr + " Nombre: " + TextBox2.Text + vbCr + " Apellido: " + TextBox3.Text + vbCr + " Fecha de nacimiento: " + DateTimePicker1.Value + vbCr + " Mail: " + TextBox6.Text + vbCr + " Telefono: " + TextBox4.Text + vbCr, vbYesNo) Then
            Dim sSQL As String = "DELETE FROM miembro WHERE id_miembro = " + TextBox1.Text
            Dim cmd As New Odbc.OdbcCommand

            Try
                cmd.CommandText = sSQL
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()
                DataGridView1.Rows().RemoveAt(DataGridView1.CurrentRow.Index)
            Catch
                MsgBox(Err.Description, MsgBoxStyle.Critical)
                Exit Sub
            End Try

            TextBox1.Text = " "
            TextBox2.Text = " "
            TextBox3.Text = " "
            TextBox4.Text = " "
            DateTimePicker1.Value = DateTime.Now
            DateTimePicker2.Value = DateTime.Now
            MsgBox("Registro eliminado")
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Falta llenar datos.", vbInformation)
        Else
            If EmailValido(LCase(TextBox6.Text)) = False Then
                MessageBox.Show("Correo electrónico no valido.", "Debe tener el formato: nombre@domino.algo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                TextBox6.SelectAll()
                TextBox6.Focus()
            Else
                If vbYes = MsgBox("Confirmar informacón: " + vbCr + " CI: " + TextBox1.Text + vbCr + " Nombre: " + TextBox2.Text + vbCr + " Apellido: " + TextBox3.Text + vbCr + " Fecha de nacimiento: " + DateTimePicker1.Value + vbCr + " Mail: " + TextBox6.Text + vbCr + " Telefono: " + TextBox4.Text + vbCr, vbYesNo) Then

                    Dim sSQL As String
                    Dim cmd As New Odbc.OdbcCommand
                    sSQL = "Insert into miembro values( "
                    sSQL = sSQL + TextBox1.Text + "," + "'" + TextBox2.Text + "'," + "'" + TextBox3.Text + "',"
                    sSQL = sSQL + "'" + DateTimePicker1.Text + "','" + DateTimePicker2.Text + "','" + TextBox6.Text + "'," + TextBox4.Text + ")"
                    MsgBox(sSQL)

                    Try
                        cmd.CommandText = sSQL
                        cmd.Connection = Form1.gcn
                        cmd.ExecuteNonQuery()

                    Catch
                        MsgBox(Err.Description, MsgBoxStyle.Critical)
                        Exit Sub
                    End Try
                    MsgBox("Registro añadido")
                End If

            End If
        End If


    End Sub



    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If EmailValido(LCase(TextBox6.Text)) = False Then
            MessageBox.Show("Correo electrónico no valido.", "Debe tener el formato: nombre@domino.algo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            TextBox6.SelectAll()
            TextBox6.Focus()
        Else
            If vbYes = MsgBox("Actualizar registro:  " + vbCr + " CI: " + TextBox1.Text + vbCr + " Nombre: " + TextBox2.Text + vbCr + " Apellido: " + TextBox3.Text + vbCr + " Fecha de nacimiento: " + DateTimePicker1.Value + vbCr + " Mail: " + TextBox6.Text + vbCr + " Telefono: " + TextBox4.Text + vbCr, vbYesNo) Then
                Dim sSQL As String
                Dim cmd As New Odbc.OdbcCommand
                sSQL = "update miembro set  "
                sSQL = sSQL + "nombre = '" + TextBox2.Text + "', apellido = " + "'" + TextBox3.Text + "', fecha_nac = "
                sSQL = sSQL + "'" + DateTimePicker1.Text + "', fecha_ingreso = '" + DateTimePicker2.Text + "', telefono = " + TextBox4.Text + " where id_miembro = " + TextBox1.Text
                MsgBox(sSQL)

                Try
                    cmd.CommandText = sSQL
                    cmd.Connection = Form1.gcn
                    cmd.ExecuteNonQuery()

                Catch
                    MsgBox(Err.Description, MsgBoxStyle.Critical)
                    Exit Sub
                End Try
                MsgBox("Registro Actualizado")
            End If
        End If
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
        If Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
        End If
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        e.Handled = Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar)
        If Not IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If Char.IsLetter(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub
    Private Sub TextBox5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox5.KeyPress
        e.Handled = Not Char.IsControl(e.KeyChar)
        If RadioButton1.Checked Then
            If Char.IsLetter(e.KeyChar) Then
                e.Handled = False
            End If
        ElseIf RadioButton3.Checked Then
            If IsNumeric(e.KeyChar) Then
                e.Handled = False
            ElseIf IsNumeric(e.KeyChar) And Not Char.IsControl(e.KeyChar) Then
                e.Handled = True
            End If
        End If
    End Sub
    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        TextBox5.Text = ""
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        TextBox5.Text = ""
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
    Private Shared Function EmailValido(strEmail As String) As Boolean
        Return System.Text.RegularExpressions.Regex.IsMatch(strEmail, "^(?("")("".+?""@)|(([0-9a-zA-Z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)(?<=[0-9a-zA-Z])@))" & "(?(\[)(\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,6}))$")
    End Function

End Class