﻿Public Class cargar
    Public Shared Sub CargaReunion(str As String, cboidreunion As ComboBox)
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        cmd.CommandText = str
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()
        While dr.Read()
            cboidreunion.Items.Add(dr(0))
        End While
    End Sub

    Public Shared Sub CargaMiembro(str As String, cbonya As ComboBox, cboid As ComboBox)
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        cmd.CommandText = str
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()
        While dr.Read()
            cbonya.Items.Add(dr(0))
            cboid.Items.Add(dr(1))
        End While
    End Sub
    Public Shared Sub AutocomS(str As String, cbo As ComboBox)
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        cmd.CommandText = str
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()
        While dr.Read()
            cbo.AutoCompleteCustomSource.Add(dr(0))
        End While
    End Sub
End Class
