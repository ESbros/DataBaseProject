﻿Public Class Consultar_Miembro
    Private Sub Consultar_Miembro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim query As String
            query = "select nombre ||' '|| apellido, id_miembro as Miembro from miembro"
            cargar.CargaMiembro(query, cbonomb, cboci)
            cargar.AutocomS(query, cbonomb)
            cargar.AutocomS(query, cboci)
        Catch ex As Exception
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
    End Sub
    Private Sub cboci_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboci.SelectedIndexChanged
        cbonomb.SelectedIndex = cboci.SelectedIndex
    End Sub
    Private Sub cbonomb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbonomb.SelectedIndexChanged
        cboci.SelectedIndex = cbonomb.SelectedIndex
    End Sub

    Private Sub btnconsultar_Click(sender As Object, e As EventArgs) Handles btnconsultar.Click
        grdr.Rows.Clear()
        grdv.Rows.Clear()
        Dim query As String
        query = "select f:: varchar, ubicacion, nivel from destino natural join (Select fecha As f , id_destino from viaje where id_viaje In(Select id_viaje from asistio_d where id_miembro=" + cboci.Text + "))As t"
        Try
            Dim cmd As New Odbc.OdbcCommand
            Dim dr As Odbc.OdbcDataReader
            cmd.CommandText = query
            cmd.Connection = Form1.gcn
            dr = cmd.ExecuteReader()
            While dr.Read()
                grdv.Rows.Add()
                grdv.Rows(grdv.RowCount - 1).Cells(0).Value = dr(0)
                grdv.Rows(grdv.RowCount - 1).Cells(1).Value = dr(1)
                grdv.Rows(grdv.RowCount - 1).Cells(2).Value = dr(2)
            End While
        Catch
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
        End Try
        query = "select fecha :: varchar ,  ubicacion,tema from reunion natural join(select id_reunion from asistio_r where id_miembro=" + cboci.Text + ")as t"
        Try
            Dim cmd As New Odbc.OdbcCommand
            Dim dr As Odbc.OdbcDataReader
            cmd.CommandText = query
            cmd.Connection = Form1.gcn
            dr = cmd.ExecuteReader()
            While dr.Read()
                grdr.Rows.Add()
                grdr.Rows(grdr.RowCount - 1).Cells(0).Value = dr(0)
                grdr.Rows(grdr.RowCount - 1).Cells(1).Value = dr(1)
                grdr.Rows(grdr.RowCount - 1).Cells(2).Value = dr(2)
            End While
        Catch
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
        End Try
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
End Class
