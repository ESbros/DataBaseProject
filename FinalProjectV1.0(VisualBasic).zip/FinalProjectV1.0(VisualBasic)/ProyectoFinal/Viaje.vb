﻿Public Class Viaje
    Private Sub Viaje_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.ReadOnly = True
        RadioButton2.Select()
        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "select id_viaje, ubicacion, id_transporte, fecha, cuota from viaje natural join destino"
        'MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)   'Ubicacion
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Nivel
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(4).Value = dr(4)
        End While
        Dim query As String
        query = "select id_destino, ubicacion from destino"
        cargar.CargaMiembro(query, cboidD, cbolug)
        query = "select id_transporte, placa from transporte"
        cargar.CargaMiembro(query, cbobusid, cboplaca)

    End Sub
    Private Sub Destinos_Click(sender As Object, e As EventArgs) Handles MyBase.Click
        TextBox1.Enabled = True

        TextBox1.Text = " "
        TextBox2.Text = " "
        cboidD.Text = " "
        cbobusid.Text = " "
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If vbYes = MsgBox("Agregar viaje a" + cbolug.Text, vbYesNo) Then

            cbobusid.SelectedIndex = cboplaca.SelectedIndex
            cboidD.SelectedIndex = cbolug.SelectedIndex
            Dim sSQL As String
            Dim cmd As New Odbc.OdbcCommand
            sSQL = "Insert into viaje values( "
            sSQL = sSQL + "default" + ",'" + DateTimePicker1.Value + "'," + cboidD.Text + "," + cbobusid.Text + "," + TextBox5.Text + ")"
            MsgBox(sSQL)

            Try
                cmd.CommandText = sSQL
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()

            Catch
                MsgBox(Err.Description, MsgBoxStyle.Critical)
                Exit Sub
            End Try
            MsgBox("Registro añadido")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Clear()

        Dim cmd As New Odbc.OdbcCommand
        Dim dr As Odbc.OdbcDataReader
        Dim sSQL As String
        sSQL = "select id_viaje, ubicacion, id_transporte, fecha, cuota from viaje natural join destino"

        MsgBox(sSQL)
        cmd.CommandText = sSQL
        cmd.Connection = Form1.gcn
        dr = cmd.ExecuteReader()

        While dr.Read()
            DataGridView1.Rows.Add()
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(0).Value = dr(0)   'ID
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(3).Value = dr(3)   'Ubicacion
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(1).Value = dr(1)   'Nivel
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(2).Value = dr(2)
            DataGridView1.Rows(DataGridView1.RowCount - 1).Cells(4).Value = dr(4)
        End While
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        Try
            TextBox2.Enabled = False

            TextBox2.Text = DataGridView1.CurrentRow.Cells(0).Value
            cboidD.Text = DataGridView1.CurrentRow.Cells(2).Value
            cbobusid.Text = DataGridView1.CurrentRow.Cells(3).Value
            DateTimePicker1.Value = DataGridView1.CurrentRow.Cells(1).Value
            TextBox5.Text = DataGridView1.CurrentRow.Cells(2).Value
        Catch
        End Try
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)
        Dim sSQL As String = "DELETE FROM viaje WHERE id_viaje = " + TextBox2.Text
        Dim cmd As New Odbc.OdbcCommand

        Try
            cmd.CommandText = sSQL
            cmd.Connection = Form1.gcn
            cmd.ExecuteNonQuery()
            DataGridView1.Rows().RemoveAt(DataGridView1.CurrentRow.Index)
        Catch
            MsgBox(Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try


        TextBox1.Text = " "
        TextBox2.Text = " "
        cboidD.Text = " "
        cbobusid.Text = " "
        TextBox5.Text = " "
        DateTimePicker1.Value = Now
        MsgBox("Registro eliminado")
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If vbYes = MsgBox("Actualizar el viaje a " + cbolug.Text + " para el día: " + DateTimePicker1.Value, vbYesNo) Then

            Dim sSQL1 As String
            Dim cmd As New Odbc.OdbcCommand
            sSQL1 = "update viaje set  fecha = '" + DateTimePicker1.Value + "', id_destino = " + cboidD.Text + ", id_transporte = " + cbobusid.Text + ", cuota = " + TextBox5.Text + " WHERE id_viaje = " + TextBox2.Text
            MsgBox(sSQL1)

            Try
                cmd.CommandText = sSQL1
                cmd.Connection = Form1.gcn
                cmd.ExecuteNonQuery()

            Catch
                MsgBox(Err.Description, MsgBoxStyle.Critical)
                Exit Sub
            End Try
            MsgBox("Registro Actualizado")
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs)
        Dim sSQL As String
        Dim cmd As New Odbc.OdbcCommand
        sSQL = "select nombre ||' '|| apellido from miembro as Miembro where id_miembro in (
select id_miembro as id from asistio_d  where id_viaje =" + TextBox2.Text + ")"
        MsgBox(sSQL)

        Try
            cmd.CommandText = sSQL
            cmd.Connection = Form1.gcn
            cmd.ExecuteNonQuery()

        Catch
            MsgBox(Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
        MsgBox("Registro añadido")
    End Sub
    Private Sub cboplaca_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboplaca.SelectedIndexChanged
        cbobusid.SelectedIndex = cboplaca.SelectedIndex
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
End Class