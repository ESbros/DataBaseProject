﻿Public Class AsistenciaViaje
    Private Sub AsistenciaViaje_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim query As String
            CargaComboIDviaje()
            query = "select nombre ||' '|| apellido, id_miembro as Miembro from miembro"
            cargar.CargaMiembro(query, cbonomb, cboci)
            cargar.AutocomS(query, cbonomb)
            cargar.AutocomS(query, cboci)

        Catch ex As Exception
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
    End Sub

    Public Sub CargaComboIDviaje()
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select id_viaje, ubicacion, fecha from viaje natural join destino order by id_viaje desc"
        dr = cmd.ExecuteReader()
        While dr.Read()
            ComboBox1.Items.Add(dr(0))
        End While
    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select ubicacion, fecha, cuota from viaje natural join destino where id_viaje = " + ComboBox1.Text
        dr = cmd.ExecuteReader()
        While dr.Read()
            TextBox1.Text = dr(0)
            TextBox2.Text = dr(1)
            TextBox4.Text = dr(2)
        End While

        Dim dr1 As Odbc.OdbcDataReader
        Dim cmd1 As New Odbc.OdbcCommand
        cmd1.Connection = Form1.gcn
        cmd1.CommandText = "select nro_ascientos, id_transporte from viaje natural join transporte where id_viaje =" + ComboBox1.Text
        dr1 = cmd1.ExecuteReader()
        While dr1.Read()
            TextBox3.Text = dr1(0)
        End While

        Dim dr2 As Odbc.OdbcDataReader
        Dim cmd2 As New Odbc.OdbcCommand
        cmd2.Connection = Form1.gcn
        cmd2.CommandText = "select count(*) from asistio_d where id_viaje =" + ComboBox1.Text
        dr2 = cmd2.ExecuteReader()
        While dr2.Read()
            TextBox5.Text = CInt(TextBox3.Text) - dr2(0)
        End While
    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If vbYes = MsgBox("Agregar asistente: " + cbonomb.Text + "con CI: " + cboci.Text + "al viaje a" + TextBox1.Text, vbYesNo) Then
            Try
                Dim sSQL As String
                Dim cmd As New Odbc.OdbcCommand
                sSQL = "Insert into asistio_d values( "
                sSQL = sSQL + cboci.Text + "," + ComboBox1.Text + "," + TextBox4.Text + ")"
                MsgBox(sSQL)

                '42
                For i = 0 To sSQL.Length - 1
                    If i > 42 And sSQL(i) = "," Then
                        sSQL = sSQL.Remove(i, 1).Insert(i, ".")
                    End If
                Next

                If CInt(TextBox5.Text) > 0 Then
                    Try
                        cmd.CommandText = sSQL
                        cmd.Connection = Form1.gcn
                        cmd.ExecuteNonQuery()

                    Catch
                        MsgBox(Err.Description, MsgBoxStyle.Critical)
                        Exit Sub
                    End Try
                    MsgBox("Registro añadido")
                Else
                    MsgBox("Cupos Agotados")
                End If

                Dim dr2 As Odbc.OdbcDataReader
                Dim cmd2 As New Odbc.OdbcCommand
                cmd2.Connection = Form1.gcn
                cmd2.CommandText = "select count(*) from asistio_d where id_viaje =" + ComboBox1.Text
                dr2 = cmd2.ExecuteReader()
                While dr2.Read()
                    TextBox5.Text = CInt(TextBox3.Text) - dr2(0)
                End While
            Catch
                MsgBox("No se encontro el usuario.")
            End Try

        End If

    End Sub

    Private Sub ComboBox2_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Char.IsNumber(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsControl(e.KeyChar) Then
            e.Handled = False
        ElseIf Char.IsSeparator(e.KeyChar) Then
            e.Handled = False
        Else e.Handled = True
        End If
    End Sub
    Private Sub cboci_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboci.SelectedIndexChanged
        cbonomb.SelectedIndex = cboci.SelectedIndex
    End Sub
    Private Sub cbonomb_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbonomb.SelectedIndexChanged
        cboci.SelectedIndex = cbonomb.SelectedIndex
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
End Class