﻿Public Class inforeunion
    Private Sub inforeunion_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            Dim query As String
            query = "select id_reunion, ubicacion, fecha,tema from reunion"
            cargar.CargaReunion(query, cboidr)
        Catch ex As Exception
            MsgBox("Al cargar datos" + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        grdasviaje.Rows.Clear()
        Dim nSQL As String
        nSQL = "select nombre ||' '|| apellido as Miembro from miembro where id_miembro in(select id_miembro from asistio_r where id_reunion = " + cboidr.Text + ")"
        Try
            Dim cmd As New Odbc.OdbcCommand
            Dim dr As Odbc.OdbcDataReader
            cmd.CommandText = nSQL
            cmd.Connection = Form1.gcn
            dr = cmd.ExecuteReader()
            While dr.Read()
                grdasviaje.Rows.Add()
                grdasviaje.Rows(grdasviaje.RowCount - 1).Cells(0).Value = dr(0)
            End While
        Catch
            MsgBox("Error al cargar datos.   " + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
        Try
            Dim sql As String
            sql = "select count(*) from miembro as Miembro where id_miembro in (select id_miembro as id from asistio_r  where id_reunion =" + cboidr.Text + ")"
            Dim cmd2 As New Odbc.OdbcCommand
            Dim dr As Odbc.OdbcDataReader
            cmd2.CommandText = sql
            cmd2.Connection = Form1.gcn
            dr = cmd2.ExecuteReader()
            While dr.Read()
                txtnumero.Text = dr(0)
            End While

        Catch

            MsgBox("Error al contar miembros.   " + Err.Description, MsgBoxStyle.Critical)
            Exit Sub
        End Try
    End Sub

    Private Sub cboidr_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboidr.SelectedIndexChanged
        Dim dr As Odbc.OdbcDataReader
        Dim cmd As New Odbc.OdbcCommand
        cmd.Connection = Form1.gcn
        cmd.CommandText = "select ubicacion,tema, fecha from reunion where id_reunion = " + cboidr.Text
        dr = cmd.ExecuteReader()
        While dr.Read()
            txtubi.Text = dr(0)
            txttema.Text = dr(1)
            txtfecha.Text = dr(2)
        End While
    End Sub
    Private Sub AñadirMiembro_Close(sender As Object, e As EventArgs) Handles MyBase.FormClosed
        Form1.GroupBox1.Visible = True
        Form1.PictureBox1.Visible = True
    End Sub
End Class